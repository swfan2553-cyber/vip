<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>
<style>
    body {
        background-image: url('https://images.unsplash.com/photo-1564475228765-f0c3292f2dec?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #2d1b4e;
        font-family: 'Poppins', sans-serif;
    }
    
    .dashboard-container {
        padding: 20px;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.7) !important;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
        overflow: hidden;
        margin-bottom: 25px;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
    }
    
    .card-header {
        background-color: rgba(93, 63, 159, 0.4) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        color: white !important;
        font-weight: 600;
        font-size: 1.2rem;
        padding: 15px 20px;
        text-align: center;
    }
    
    .card-body {
        padding: 20px;
        color: white;
    }
    
    #exp {
        font-family: 'Nova Mono', monospace;
        text-align: center;
        color: #fff;
        font-size: 3rem;
        text-shadow: 0px 0px 20px #a78bfa;
        margin: 0;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.7; }
        100% { opacity: 1; }
    }
    
    .list-group-item {
        background-color: rgba(93, 63, 159, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: white;
        transition: all 0.3s ease;
        padding: 12px 20px;
        margin-bottom: 5px;
        border-radius: 8px;
    }
    
    .list-group-item:hover {
        background-color: rgba(93, 63, 159, 0.5);
        transform: translateX(5px);
    }
    
    .badge {
        padding: 8px 15px;
        border-radius: 50px;
        font-weight: 500;
        font-size: 0.85rem;
    }
    
    .badge.text-success {
        background-color: rgba(40, 167, 69, 0.2);
        color: #4ade80 !important;
    }
    
    .badge.text-danger {
        background-color: rgba(220, 53, 69, 0.2);
        color: #f87171 !important;
    }
    
    .badge.text-primary {
        background-color: rgba(13, 110, 253, 0.2);
        color: #60a5fa !important;
    }
    
    .badge.text-dark {
        background-color: rgba(255, 255, 255, 0.2);
        color: white !important;
    }
    
    .badge.text-muted {
        background-color: rgba(108, 117, 125, 0.2);
        color: #d1d5db !important;
    }
    
    .table {
        color: white;
    }
    
    .table-bordered {
        border-color: rgba(255, 255, 255, 0.1);
    }
    
    .table-hover tbody tr:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .stat-card {
        text-align: center;
        padding: 15px;
    }
    
    .stat-icon {
        font-size: 2.5rem;
        margin-bottom: 15px;
        color: #a78bfa;
        animation: float 3s ease-in-out infinite;
    }
    
    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
    }
    
    .stat-value {
        font-size: 2.5rem;
        font-weight: bold;
        margin-bottom: 5px;
        background: linear-gradient(45deg, #a78bfa, #60a5fa);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    .stat-label {
        font-size: 1rem;
        opacity: 0.8;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .animate-in {
        animation: fadeIn 0.5s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @media only screen and (max-width: 768px) {
        #exp { font-size: 2rem; }
        .stat-value { font-size: 1.8rem; }
    }
</style>

<div class="dashboard-container">
    <div class="row">
        <div class="col-lg-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
        
 
                        </div>
                    
        <!-- Expiration Card -->
        <div class="col-lg-8 animate-in" style="animation-delay: 0.5s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-clock-history me-2"></i> Expiration
                </div>
                <div class="card-body">
                    <p id="exp"></p>
                </div>
            </div>
        </div>
        
        <!-- User Info Card -->
        <div class="col-lg-4 animate-in" style="animation-delay: 0.6s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-person-badge me-2"></i> Information
                </div>
                <div class="card-body">
                    <ul class="list-group list-hover mb-3">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-person-fill me-2"></i> Role</span>
                            <span class="badge text-dark">
                                <?= getLevel($user->level) ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-wallet-fill me-2"></i> Balance</span>
                            <span class="badge text-dark">
                                ₹<?= $user->saldo ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-clock-fill me-2"></i> Login Time</span>
                            <span class="badge text-dark">
                                <?= $time::parse(session()->time_since)->humanize() ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-box-arrow-right me-2"></i> Auto Log-out</span>
                            <span class="badge text-dark">
                                <?= $time::now()->difference($time::parse(session()->time_login))->humanize() ?>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- History Card -->
        <div class="col-lg-8 animate-in" style="animation-delay: 0.7s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-clock-history me-2"></i> History
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered table-hover text-center">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Info</th>
                                    <th>Code</th>
                                    <th>Duration</th>
                                    <th>Devices</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($history as $h) : ?>
                                    <?php $in = explode("|", $h->info) ?>
                                    <tr>
                                        <td><span class="align-middle badge text-dark">#3812<?= $h->id_history ?></span></td>
                                        <td><?= $in[0] ?></td>
                                        <td><span class="align-middle badge text-dark"><?= $in[1] ?>**</span></td>
                                        <td><span class="align-middle badge text-dark"><?= HoursToDays($in[2]); ?></span></td>
                                        <td><span class="align-middle badge text-primary"><?= $in[3] ?> Devices</span></td>
                                        <td><i class="align-middle badge text-muted"><?= $time::parse($h->created_at)->humanize() ?></i></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Activity Chart -->
        <div class="col-lg-4 animate-in" style="animation-delay: 0.8s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-activity me-2"></i> Activity
                </div>
                <div class="card-body">
                    <div class="chart-container" style="position: relative; height: 250px;">
                        <canvas id="activityChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Required JS Libraries -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?= $this->endSection() ?>