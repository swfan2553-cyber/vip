<style>
    .custom-navbar {
        background: linear-gradient(135deg, #5d3f9f 0%, #7b52c5 100%) !important;
        backdrop-filter: blur(15px);
        -webkit-backdrop-filter: blur(15px);
        box-shadow: 0 4px 25px rgba(93, 63, 159, 0.4);
        border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        position: sticky;
        top: 0;
        z-index: 1050;
        padding: 12px 0;
        transition: all 0.3s ease;
    }
    
    .navbar-brand {
        color: white !important;
        font-weight: 700;
        font-size: 1.5rem;
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 8px 0;
    }
    
    .navbar-brand i {
        font-size: 1.8rem;
        background: rgba(255, 255, 255, 0.15);
        padding: 8px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }
    
    .nav-link {
        color: rgba(255, 255, 255, 0.9) !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        padding: 10px 20px !important;
        border-radius: 10px;
        margin: 0 5px;
        font-weight: 500;
        font-size: 1rem;
        position: relative;
        overflow: hidden;
    }
    
    .nav-link::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 0;
        height: 2px;
        background: linear-gradient(90deg, #ff6b9d, #ffd166);
        transition: width 0.3s ease;
        border-radius: 2px;
    }
    
    .nav-link:hover {
        color: white !important;
        background: rgba(255, 255, 255, 0.12);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }
    
    .nav-link:hover::before {
        width: 70%;
    }
    
    .nav-link.active {
        background: linear-gradient(135deg, rgba(255, 107, 157, 0.2), rgba(255, 209, 102, 0.2));
        color: white !important;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(255, 107, 157, 0.3);
    }
    
    .navbar-toggler {
        border: 2px solid rgba(255, 255, 255, 0.3);
        padding: 8px 12px;
        border-radius: 10px;
        transition: all 0.3s;
    }
    
    .navbar-toggler:hover {
        border-color: rgba(255, 255, 255, 0.6);
        background: rgba(255, 255, 255, 0.1);
    }
    
    .navbar-toggler:focus {
        box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.25);
        outline: none;
    }
    
    .navbar-toggler-icon {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.95%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='3' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        width: 1.3em;
        height: 1.3em;
        transition: transform 0.3s;
    }
    
    .navbar-toggler[aria-expanded="true"] .navbar-toggler-icon {
        transform: rotate(90deg);
    }
    
    .dropdown-toggle {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50px;
        padding: 8px 20px !important;
        border: 1px solid rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(10px);
    }
    
    .dropdown-toggle:hover {
        background: rgba(255, 255, 255, 0.2);
        border-color: rgba(255, 255, 255, 0.4);
    }
    
    .dropdown-menu {
        background: linear-gradient(135deg, rgba(93, 63, 159, 0.98), rgba(123, 82, 197, 0.98));
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        border-radius: 15px;
        padding: 10px 0;
        margin-top: 15px;
        min-width: 220px;
        animation: dropdownFade 0.3s ease;
    }
    
    @keyframes dropdownFade {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .dropdown-menu::before {
        content: '';
        position: absolute;
        top: -7px;
        right: 25px;
        width: 14px;
        height: 14px;
        background: linear-gradient(135deg, rgba(93, 63, 159, 0.98), rgba(123, 82, 197, 0.98));
        transform: rotate(45deg);
        border-top: 1px solid rgba(255, 255, 255, 0.2);
        border-left: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-item {
        color: rgba(255, 255, 255, 0.95) !important;
        padding: 12px 25px !important;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 0.95rem;
        border-left: 3px solid transparent;
        margin: 2px 8px;
        border-radius: 8px;
        width: auto;
    }
    
    .dropdown-item i {
        width: 22px;
        text-align: center;
        font-size: 1.2rem;
        opacity: 0.9;
    }
    
    .dropdown-item:hover {
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.18), rgba(255, 255, 255, 0.12)) !important;
        color: white !important;
        border-left: 3px solid #ff6b9d;
        padding-left: 28px !important;
        transform: translateX(3px);
    }
    
    .dropdown-divider {
        border-top: 1px solid rgba(255, 255, 255, 0.15);
        margin: 8px 15px;
        opacity: 0.5;
    }
    
    .navbar-nav {
        align-items: center;
    }
    
    .user-dropdown {
        margin-left: auto;
    }
    
    .user-avatar {
        width: 36px;
        height: 36px;
        background: linear-gradient(135deg, #ff6b9d, #ffd166);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 8px;
        font-weight: bold;
        color: white;
        box-shadow: 0 4px 10px rgba(255, 107, 157, 0.4);
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .custom-navbar {
            padding: 8px 0;
        }
        
        .navbar-brand {
            font-size: 1.3rem;
        }
        
        .navbar-brand i {
            padding: 6px;
            font-size: 1.5rem;
        }
        
        .nav-link {
            padding: 10px 15px !important;
            margin: 2px 0;
            text-align: center;
        }
        
        .dropdown-menu {
            width: 95%;
            margin: 10px auto;
            position: static !important;
            transform: none !important;
        }
        
        .dropdown-menu::before {
            display: none;
        }
        
        .dropdown-toggle {
            justify-content: center;
            margin-top: 10px;
        }
    }
</style>

<header>
    <nav class="navbar navbar-expand-lg navbar-dark custom-navbar">
        <div class="container px-4">
            <!-- Brand Logo -->
            <a class="navbar-brand" href="<?= site_url() ?>">
                <i class="bi bi-stars"></i>
                <span><?= htmlspecialchars(BASE_NAME ?? 'WATAN VIP', ENT_QUOTES, 'UTF-8') ?></span>
            </a>
            
            <!-- Mobile Toggle Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Main Navbar Content -->
            <div class="collapse navbar-collapse" id="navbarMain">
                <?php if (session()->has('userid') && isset($user)): ?>
                    <!-- Main Navigation Links -->
                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link <?= (current_url() == site_url('keys')) ? 'active' : '' ?>" href="<?= site_url('keys') ?>">
                                <i class="bi bi-key me-1"></i>Keys
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= (current_url() == site_url('keys/generate')) ? 'active' : '' ?>" href="<?= site_url('keys/generate') ?>">
                                <i class="bi bi-plus-circle me-1"></i>Generate
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= (current_url() == site_url('settings')) ? 'active' : '' ?>" href="<?= site_url('settings') ?>">
                                <i class="bi bi-gear me-1"></i>Settings
                            </a>
                        </li>
                    </ul>
                    
                    <!-- User Dropdown -->
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="user-avatar me-2">
                                    <?= strtoupper(substr(getName($user) ?? 'U', 0, 1)) ?>
                                </div>
                                <span class="d-none d-md-inline"><?= htmlspecialchars(getName($user) ?? 'User', ENT_QUOTES, 'UTF-8') ?></span>
                            </a>
                            
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <!-- User Info -->
                                <li class="px-4 py-3">
                                    <h6 class="mb-0 text-white fw-bold"><?= htmlspecialchars(getName($user) ?? 'User', ENT_QUOTES, 'UTF-8') ?></h6>
                                    <small class="text-white-50"><?= htmlspecialchars($user->email ?? '', ENT_QUOTES, 'UTF-8') ?></small>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                
                                <!-- Admin Links -->
                                <?php if (isset($user->level) && ($user->level == 1 || $user->level == 2)): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?= site_url('Server') ?>">
                                            <i class="bi bi-play-circle"></i>Online System
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="<?= site_url('admin/manage-users') ?>">
                                            <i class="bi bi-people"></i>Manage Users
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="<?= site_url('admin/create-referral') ?>">
                                            <i class="bi bi-person-plus"></i>Create Referral
                                        </a>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                <?php endif; ?>
                                
                                <!-- Logout -->
                                <li>
                                    <a class="dropdown-item text-danger" href="<?= site_url('logout') ?>">
                                        <i class="bi bi-box-arrow-right"></i>Logout
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</header>

<script>
    // Add smooth scrolling and active link management
    document.addEventListener('DOMContentLoaded', function() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        // Update active link based on current URL
        navLinks.forEach(link => {
            if (link.href === window.location.href) {
                link.classList.add('active');
            }
        });
        
        // Add hover effects to dropdown
        const dropdowns = document.querySelectorAll('.dropdown');
        dropdowns.forEach(dropdown => {
            dropdown.addEventListener('mouseenter', function() {
                this.querySelector('.dropdown-toggle').click();
            });
        });
        
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.custom-navbar');
            if (window.scrollY > 50) {
                navbar.style.boxShadow = '0 4px 30px rgba(93, 63, 159, 0.5)';
                navbar.style.padding = '8px 0';
            } else {
                navbar.style.boxShadow = '0 4px 25px rgba(93, 63, 159, 0.4)';
                navbar.style.padding = '12px 0';
            }
        });
    });
</script>