<?php

$servername = "localhost";
$username = "qilerbty_vip";
$password = "77Jw7zxmhgx4dzTqQWUZ";
$dbname = "qilerbty_vip";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>