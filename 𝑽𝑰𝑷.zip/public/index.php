<?php
// ==================== ZIP FILES PROTECTION ====================
// هذا الكود يحمي ملفات ZIP ومحتوياتها في uploads

// المفتاح الخاص بالتطبيق
$APP_API_KEY = 'APP_PROD_KEY_XYZ789VIP'; // غير هذا للمفتاح الحقيقي

// معلومات الطلب
$request_uri = $_SERVER['REQUEST_URI'] ?? '';
$request_uri_lower = strtolower($request_uri);

// دالة للحصول على API Key
function getApiKey() {
    // من X-API-Key header
    $headers = getallheaders();
    foreach ($headers as $key => $value) {
        if (strtolower($key) === 'x-api-key') {
            return trim($value);
        }
    }
    // من query parameter
    return isset($_GET['api_key']) ? trim($_GET['api_key']) : '';
}

// تحقق إذا كان طلب ملف ZIP أو محتوياته في uploads
if ((strpos($request_uri_lower, '/public/uploads/') !== false || 
     strpos($request_uri_lower, '/uploads/') !== false)) {
    
    $client_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $filename = basename($request_uri);
    
    // قائمة الملفات المحمية داخل KRADH.zip
    $protected_files_in_zip = [
        'KRADH.zip',                    // الملف الرئيسي
        'KRASH.zip',  
        'KRADH.json',      
        // أضف هنا أسماء الملفات الموجودة داخل ZIP
        'config.json',
        'settings.ini',
        'data.db',
        'lib.so',
        'module.dll',
        // أو استخدم patterns
        '/\.(so|dll|exe|bin)$/i',      // ملفات تنفيذية
        '/\.(json|ini|cfg|conf)$/i',   // ملفات إعدادات
        '/\.(db|sqlite|dat)$/i',       // قواعد بيانات
    ];
    
    // تحقق إذا كان الملف محمياً
    $is_protected = false;
    
    // 1. تحقق إذا كان ملف ZIP
    if (preg_match('/\.zip$/i', $filename)) {
        $is_protected = true;
    }
    
    // 2. تحقق إذا كان طلب محتويات ZIP (مثل: file.zip# أو file.zip/)
    if (preg_match('/\.zip(#|\/|\\?|$)/i', $request_uri_lower)) {
        $is_protected = true;
    }
    
    // 3. تحقق إذا كان اسم ملف محمي من القائمة
    foreach ($protected_files_in_zip as $pattern) {
        if (strpos($pattern, '/') === 0) {
            // إذا كان pattern (تعبير منتظم)
            if (preg_match($pattern, $filename)) {
                $is_protected = true;
                break;
            }
        } else {
            // إذا كان نصاً عادياً
            if (strcasecmp($filename, $pattern) === 0) {
                $is_protected = true;
                break;
            }
        }
    }
    
    // 4. تحقق إذا كان الطلب لمحتويات أرشيف (مثل: path/to/file.zip/somefile.txt)
    if (preg_match('/\.zip\/[^\/]+$/i', $request_uri_lower)) {
        $is_protected = true;
    }
    
    // إذا كان الملف محمياً، تحقق من API Key
    if ($is_protected) {
        // تسجيل المحاولة
        $log_file = __DIR__ . '/protected_access.log';
        $log_entry = date('Y-m-d H:i:s') . " | IP: $client_ip | URI: $request_uri | " .
                     "FILENAME: $filename | KEY: " . (getApiKey() ? 'YES' : 'NO') . PHP_EOL;
        @file_put_contents($log_file, $log_entry, FILE_APPEND);
        
        // التحقق من المفتاح
        if (getApiKey() !== $APP_API_KEY) {
            // منع الوصول
            http_response_code(403);
            header('Content-Type: text/html; charset=utf-8');
            ?>
            <!DOCTYPE html>
            <html dir="rtl">
            <head><title>الوصول محظور</title>
            <style>
                body{background:#000;color:#ff0000;font-family:Arial;padding:50px;text-align:center}
                h1{color:#ff0000;margin:20px 0}
                .box{background:#220000;padding:20px;border:2px solid #ff0000;margin:20px auto;max-width:600px}
                .warning{color:#ff9900;font-weight:bold;margin:15px 0}
            </style>
            </head>
            <body>
                <div class="box">
                    <h1>🔒 الوصول محظور</h1>
                    
                    <div class="warning">⛔ الملف المحمي: <?php echo htmlspecialchars($filename); ?></div>
                    
                    <p>هذا الملف محمي ولا يمكن الوصول إليه مباشرة.</p>
                    <p>يجب استخدام <strong>التطبيق الرسمي</strong> للوصول إلى هذا الملف.</p>
                    
                    <p style="margin-top:20px;color:#ccc;">
                        <?php
                        if (preg_match('/\.zip$/i', $filename)) {
                            echo "⚠️ ملفات ZIP محمية بالكامل";
                        } else {
                            echo "⚠️ هذا الملف جزء من الأرشيف المحمي";
                        }
                        ?>
                    </p>
                    
                    <p>IP: <?php echo htmlspecialchars($client_ip); ?></p>
                    <p>الوقت: <?php echo date('Y-m-d H:i:s'); ?></p>
                </div>
            </body>
            </html>
            <?php
            exit;
        }
        
        // إذا المفتاح صحيح، اسمح بتنزيل الملف
        $success_log = __DIR__ . '/access_granted.log';
        $success_entry = date('Y-m-d H:i:s') . " | GRANTED | IP: $client_ip | FILE: " . 
                         basename($request_uri) . PHP_EOL;
        @file_put_contents($success_log, $success_entry, FILE_APPEND);
    }
}
// ==================== END ZIP PROTECTION ====================

// ==================== الكود الأصلي ====================

// Path to the front controller (this file)
define('FCPATH', __DIR__ . DIRECTORY_SEPARATOR);

// Ensure the current directory is pointing to the front controller's directory
chdir(__DIR__);

// Load our paths config file
$pathsConfig = FCPATH . '../app/Config/Paths.php';
require realpath($pathsConfig) ?: $pathsConfig;

$paths = new Config\Paths();

// Location of the framework bootstrap file.
$bootstrap = rtrim($paths->systemDirectory, '\\/ ') . DIRECTORY_SEPARATOR . 'bootstrap.php';
$app       = require realpath($bootstrap) ?: $bootstrap;

$app->run();