<?php

if (!function_exists('checkRateLimit')) {
    function checkRateLimit() {
        $cache_dir = sys_get_temp_dir() . '/rate_limit/';
        
        if (!file_exists($cache_dir)) {
            mkdir($cache_dir, 0755, true);
        }
        
        $global_block_file = $cache_dir . 'GLOBAL_BLOCK';
        $current_time = time();
        $block_duration = 6000;
        $rate_limit = 5;
        $rate_limit_period = 30;
        
        cleanOldCacheFiles($cache_dir, $block_duration);
        
        if (file_exists($global_block_file)) {
            $block_time = filemtime($global_block_file);
            if ($current_time - $block_time < $block_duration) {
                header('Location: n.html');
                exit;
            } else {
                unlink($global_block_file);
            }
        }
        
        $ip_addresses = [];
        $ip_keys = [
            'REMOTE_ADDR',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED'
        ];
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) && !empty($_SERVER[$key])) {
                $values = explode(',', $_SERVER[$key]);
                foreach ($values as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP)) {
                        $ip_addresses[] = $ip;
                    }
                }
            }
        }
        
        $ip_addresses = array_unique($ip_addresses);
        if (empty($ip_addresses)) {
            $ip_addresses = ['unknown'];
        }
        
        foreach ($ip_addresses as $ip) {
            $cache_file = $cache_dir . md5($ip);
            
            if (file_exists($cache_file)) {
                $data = json_decode(file_get_contents($cache_file), true);
                
                if ($current_time - $data['first_request'] <= $rate_limit_period) {
                    $data['count']++;
                    
                    if ($data['count'] >= $rate_limit) {
                        file_put_contents($global_block_file, '1');
                        header('Location: n.html');
                        exit;
                    }
                } else {
                    $data = [
                        'first_request' => $current_time,
                        'count' => 1
                    ];
                }
            } else {
                $data = [
                    'first_request' => $current_time,
                    'count' => 1
                ];
            }
            
            file_put_contents($cache_file, json_encode($data));
        }
    }
}

if (!function_exists('cleanOldCacheFiles')) {
    function cleanOldCacheFiles($cache_dir, $max_age) {
        $files = glob($cache_dir . '*');
        $current_time = time();
        
        foreach ($files as $file) {
            if (filemtime($file) < ($current_time - $max_age)) {
                unlink($file);
            }
        }
    }
}

checkRateLimit();

// ==================== حماية كاملة لمجلد uploads ====================
// API Keys المسموحة للتطبيق
$app_api_keys = [
    'APP_PROD_KEY_XYZ789VIP',  // المفتاح الرئيسي للتطبيق
    // أضف مفاتيح إضافية إذا كان لديك أكثر من تطبيق
];

// قائمة User-Agents المسموحة للتطبيق
$app_user_agents = [
    'BoxLoader/',        // تطبيقك
    'MyApp/',           // إذا كان لديك تطبيق آخر
    'Android-App/',     // تطبيقات أندرويد عامة
];

// IPs مسموحة (اختياري - للصيانة فقط)
$allowed_ips = [
    // '156.202.219.83', // IP الصيانة
];

// الحصول على معلومات الطلب
$request_uri = $_SERVER['REQUEST_URI'] ?? '';
$request_uri_lower = strtolower($request_uri);
$client_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$request_method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// دالة للتحقق من الـ API Key
function get_api_key() {
    // من X-API-Key header
    $headers = getallheaders();
    foreach ($headers as $key => $value) {
        if (strtolower($key) === 'x-api-key') {
            return trim($value);
        }
    }
    
    // من Authorization header
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth_header = $_SERVER['HTTP_AUTHORIZATION'];
        if (strpos($auth_header, 'Bearer ') === 0) {
            return trim(substr($auth_header, 7));
        }
        return trim($auth_header);
    }
    
    // من query parameter
    if (isset($_GET['api_key'])) {
        return trim($_GET['api_key']);
    }
    
    // من POST data
    if (isset($_POST['api_key'])) {
        return trim($_POST['api_key']);
    }
    
    return '';
}

// تحقق إذا كان الطلب لمجلد uploads
if (strpos($request_uri_lower, '/public/uploads/') !== false || 
    strpos($request_uri_lower, '/uploads/') !== false) {
    
    // تسجيل محاولة الوصول
    $access_log = sys_get_temp_dir() . '/uploads_access_attempts.log';
    $log_entry = sprintf(
        "[%s] IP:%s | Method:%s | URI:%s | Agent:%s | Key:%s%s",
        date('Y-m-d H:i:s'),
        $client_ip,
        $request_method,
        $request_uri,
        substr($user_agent, 0, 100),
        (get_api_key() ? 'YES' : 'NO'),
        PHP_EOL
    );
    @file_put_contents($access_log, $log_entry, FILE_APPEND);
    
    // 1. التحقق من IP المسموح (للصيانة فقط)
    if (in_array($client_ip, $allowed_ips)) {
        // السماح للـ IP المسموح
        goto ALLOW_ACCESS;
    }
    
    // 2. التحقق من الـ API Key
    $api_key = get_api_key();
    if (in_array($api_key, $app_api_keys)) {
        // تسجيل وصول ناجح
        $success_log = sys_get_temp_dir() . '/uploads_access_granted.log';
        $success_entry = sprintf(
            "[%s] ACCESS GRANTED via API Key | IP:%s | File:%s%s",
            date('Y-m-d H:i:s'),
            $client_ip,
            basename($request_uri),
            PHP_EOL
        );
        @file_put_contents($success_log, $success_entry, FILE_APPEND);
        goto ALLOW_ACCESS;
    }
    
    // 3. التحقق من User-Agent للتطبيق
    $is_app_user_agent = false;
    foreach ($app_user_agents as $app_agent) {
        if (strpos($user_agent, $app_agent) !== false) {
            $is_app_user_agent = true;
            break;
        }
    }
    
    if ($is_app_user_agent && !empty($api_key)) {
        // User-Agent + API Key معاً
        $success_log = sys_get_temp_dir() . '/uploads_access_granted.log';
        $success_entry = sprintf(
            "[%s] ACCESS GRANTED via App | IP:%s | Agent:%s | File:%s%s",
            date('Y-m-d H:i:s'),
            $client_ip,
            substr($user_agent, 0, 50),
            basename($request_uri),
            PHP_EOL
        );
        @file_put_contents($success_log, $success_entry, FILE_APPEND);
        goto ALLOW_ACCESS;
    }
    
    // 4. رفض جميع الطلبات الأخرى
    // تسجيل محاولة غير مصرح بها
    $block_log = sys_get_temp_dir() . '/uploads_blocked.log';
    $block_entry = sprintf(
        "[%s] BLOCKED | IP:%s | Method:%s | URI:%s | Agent:%s%s",
        date('Y-m-d H:i:s'),
        $client_ip,
        $request_method,
        $request_uri,
        substr($user_agent, 0, 100),
        PHP_EOL
    );
    @file_put_contents($block_log, $block_entry, FILE_APPEND);
    
    // إرجاع رد الرفض
    if (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false ||
        strpos($user_agent, 'curl') !== false ||
        strpos($user_agent, 'wget') !== false) {
        
        // رد JSON للـ APIs
        header('HTTP/1.1 403 Forbidden');
        header('Content-Type: application/json');
        
        echo json_encode([
            'error' => true,
            'code' => 'ACCESS_DENIED',
            'message' => 'Access to uploads directory is restricted',
            'details' => 'Only authorized applications can access this directory',
            'required' => 'Valid API key and authorized User-Agent',
            'timestamp' => time(),
            'ip' => $client_ip
        ], JSON_UNESCAPED_UNICODE);
        
    } else {
        // رد HTML للمتصفحات
        header('HTTP/1.1 403 Forbidden');
        header('Content-Type: text/html; charset=utf-8');
        
        echo '<!DOCTYPE html>
        <html dir="rtl">
        <head>
            <title>403 - الوصول ممنوع</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
                    color: #fff;
                    font-family: "Segoe UI", Arial, sans-serif;
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                }
                .container {
                    background: rgba(25, 25, 35, 0.95);
                    border: 2px solid #ff4757;
                    border-radius: 15px;
                    padding: 40px;
                    max-width: 800px;
                    width: 100%;
                    text-align: center;
                    box-shadow: 0 10px 40px rgba(255, 71, 87, 0.3);
                }
                .icon {
                    font-size: 5em;
                    margin-bottom: 20px;
                    color: #ff4757;
                    animation: shake 0.5s;
                }
                @keyframes shake {
                    0%, 100% { transform: translateX(0); }
                    25% { transform: translateX(-10px); }
                    75% { transform: translateX(10px); }
                }
                h1 {
                    color: #ff4757;
                    margin-bottom: 20px;
                    font-size: 2.5em;
                }
                .message {
                    background: rgba(255, 71, 87, 0.1);
                    border-right: 5px solid #ff4757;
                    padding: 20px;
                    margin: 25px 0;
                    text-align: right;
                    border-radius: 10px;
                    font-size: 1.1em;
                }
                .app-link {
                    display: inline-block;
                    background: linear-gradient(135deg, #3742fa 0%, #5352ed 100%);
                    color: white;
                    padding: 15px 40px;
                    margin: 20px 0;
                    border-radius: 50px;
                    text-decoration: none;
                    font-weight: bold;
                    font-size: 1.2em;
                    transition: all 0.3s;
                }
                .app-link:hover {
                    transform: translateY(-3px);
                    box-shadow: 0 10px 20px rgba(55, 66, 250, 0.4);
                }
                .details {
                    background: rgba(255, 255, 255, 0.05);
                    padding: 15px;
                    margin: 15px 0;
                    border-radius: 8px;
                    font-family: monospace;
                    font-size: 0.9em;
                    text-align: left;
                    overflow-x: auto;
                }
                .warning {
                    color: #ffa502;
                    font-weight: bold;
                    margin: 10px 0;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="icon">🔒</div>
                <h1>الوصول إلى الملفات محظور</h1>
                
                <div class="message">
                    <strong>هذا المجلد محمي ومخصص للتطبيقات المصرح بها فقط</strong><br><br>
                    لا يمكن الوصول إلى ملفات التحميل من خلال المتصفح أو الروابط المباشرة.<br>
                    يجب استخدام <strong>التطبيق الرسمي</strong> للوصول إلى هذه الملفات.
                </div>
                
                <div class="warning">
                    ⚠️ جميع محاولات الوصول غير المصرح بها يتم تسجيلها
                </div>
                
                <a href="https://play.google.com/store/apps/details?id=pubgm.loader" 
                   class="app-link" target="_blank">
                   📲 تنزيل التطبيق الرسمي
                </a>
                
                <div class="details">
                    <strong>تفاصيل الحادث:</strong><br>
                    • عنوان IP: ' . htmlspecialchars($client_ip) . '<br>
                    • الملف المطلوب: ' . htmlspecialchars(basename($request_uri)) . '<br>
                    • التاريخ والوقت: ' . date('Y-m-d H:i:s') . '<br>
                    • عميل المستخدم: ' . htmlspecialchars(substr($user_agent, 0, 150)) . '
                </div>
                
                <p style="margin-top: 20px; color: #aaa; font-size: 0.9em;">
                    نظام الحماية: Secure Uploads Directory<br>
                    المرجع: ' . uniqid('BLOCK', true) . '
                </p>
            </div>
        </body>
        </html>';
    }
    
    exit;
}

ALLOW_ACCESS:
// السماح بالوصول
// ==================== نهاية حماية uploads ====================

define('FCPATH', __DIR__ . DIRECTORY_SEPARATOR);
chdir(__DIR__);

$pathsConfig = FCPATH . 'app/Config/Paths.php';
require realpath($pathsConfig) ?: $pathsConfig;

$paths = new Config\Paths();
$bootstrap = rtrim($paths->systemDirectory, '\\/ ') . DIRECTORY_SEPARATOR . 'bootstrap.php';
$app = require realpath($bootstrap) ?: $bootstrap;

$app->run();